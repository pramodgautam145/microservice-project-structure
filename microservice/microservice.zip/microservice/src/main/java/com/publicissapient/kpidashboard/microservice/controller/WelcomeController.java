package com.publicissapient.kpidashboard.microservice.controller;


import com.publicissapient.kpidashboard.microservice.client.RestClient;
import com.publicissapient.kpidashboard.microservice.model.Demo;
import com.publicissapient.kpidashboard.microservice.service.AppService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
//@Slf4j
public class WelcomeController {

    @Autowired
    private AppService appService;
    @Autowired
    private RestClient restClient;
    private static final Logger logger = LoggerFactory.getLogger(WelcomeController.class);
    @GetMapping("/services")
    public String welcome() {
        logger.info("welcome to Controller {}", "WelcomeController");
        logger.info("Trace ID: {}", MDC.get("traceId"));
        logger.info("Span ID: {}", MDC.get("spanId"));
        return "Welcome to KPI Dashboard Microservice!";
    }
    @GetMapping("/retrieve")
    public List<Demo> retrieveDemoData() {
        logger.info("request recieve demo data");
        List<Demo> list = appService.callingAppService();
        //MDC.clear();
        return list;
    }

}
