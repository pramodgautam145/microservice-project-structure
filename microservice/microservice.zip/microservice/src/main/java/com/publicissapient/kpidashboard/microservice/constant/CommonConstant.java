package com.publicissapient.kpidashboard.microservice.constant;

public class CommonConstant {

    public static final String url = "/getData";
}
