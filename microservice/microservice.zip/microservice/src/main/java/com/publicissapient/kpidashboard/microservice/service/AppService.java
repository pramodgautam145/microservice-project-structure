package com.publicissapient.kpidashboard.microservice.service;

import com.publicissapient.kpidashboard.microservice.model.Demo;

import java.util.List;

public interface AppService {
    public List<Demo> callingAppService();
}
